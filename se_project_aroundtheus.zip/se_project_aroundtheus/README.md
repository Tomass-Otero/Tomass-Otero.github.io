Project Around The U.S. ©Tripleten

Welcome to my project, made with HTML and CSS.

~ ~

The main idea of the page is an interactive layout where users can add, remove, and like photos of other users, and make a few minor adjustments to their own profiles.g
The principal objective of this project was to be able to make a responsive design for the webpage, modifying the vh and making it interactive to use either on a regular computer, a tablet or a smartphone.

~ ~

In case you want to contribute, you can:

1. Fork the repository
2. Clone the forked repository.
3. Add your contributions (code or documentation).
4. Commit and push.

~ ~

link to the repository (git@github.com:Tomass-Otero/se_project_aroundtheus.git)
(https://github.com/Tomass-Otero/se_project_aroundtheus.git)
